"""Offline deterministic media skill."""
